﻿//Student Name:Akshar Patel
//Student ID: 000916856

using System;

namespace LAB_RECURSION
{
    public class Program
    {
        static void Main(string[] args)
        {
            //user to enter the value for 'n'
            Console.WriteLine("Enter number n: ");
            int n = Convert.ToInt32(Console.ReadLine());

            //user to enter the value for 'm'
            Console.WriteLine("Enter number m: ");
            int m = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Sum from {n} to {m}: {SumRecursive(n, m)}");

            Console.WriteLine();

            //Perform division by two and count the number of divisions
            Console.WriteLine("Division by Two");
            Console.WriteLine("Enter your number: ");
            int div = Convert.ToInt32(Console.ReadLine());
            DivisionByTwo(div, out int divisions);
            Console.WriteLine($"Total number of divisions: {divisions}");

            Console.ReadLine();
        }

        public static int SumRecursive(int n, int m)
        {
            if (n == m)
            {
                return n;
            }
            else
            {
                return n + SumRecursive(n + 1, m);
            }
        }

        // Function to perform division by two and count the number of divisions
        public static void DivisionByTwo(int div, out int divisions)
        {
            divisions = 0;
            while (div % 2 == 0)
            {
                div = div / 2;
                divisions++;
            }
        }
    }
}
